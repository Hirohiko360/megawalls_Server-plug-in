package net.nuggetmc.mw.luckdraw

enum class SwordNameRarity(val probabilityPercent: Double) {

    //MYTHIC(0.0),
    //WE DONT HAVE MYTHIC ITEMS YET
    LEGENDARY(10.0),
    EPIC(15.0),
    RARE(30.0),
    UNCOMMON(45.0);

}