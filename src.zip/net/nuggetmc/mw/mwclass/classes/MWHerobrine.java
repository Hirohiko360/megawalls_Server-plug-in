package net.nuggetmc.mw.mwclass.classes;

import net.md_5.bungee.api.ChatColor;
import net.nuggetmc.mw.mwclass.MWClass;
import net.nuggetmc.mw.mwclass.info.Diamond;
import net.nuggetmc.mw.mwclass.info.MWClassInfo;
import net.nuggetmc.mw.mwclass.info.Playstyle;
import net.nuggetmc.mw.mwclass.items.MWItem;
import net.nuggetmc.mw.mwclass.items.MWKit;
import net.nuggetmc.mw.mwclass.items.MWPotions;
import net.nuggetmc.mw.utils.ActionBar;
import net.nuggetmc.mw.utils.PotionUtils;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;
import java.util.*;

public class MWHerobrine extends MWClass {

    private final Map<Player, Integer> increment = new HashMap<>();
    private final Set<Player> wrathList = new HashSet<>();

    public MWHerobrine() {
        this.name = new String[]{"Herobrine", "Herobrine", "HBR"/*, "RockstarGamesOL", "张泽旭"*/};
        this.icon = Material.DIAMOND_SWORD;
        this.color = ChatColor.YELLOW;

        this.playstyles = new Playstyle[]{
                Playstyle.DAMAGE,
                Playstyle.CONTROL
        };

        this.diamonds = new Diamond[]{
                Diamond.SWORD
        };

        this.classInfo = new MWClassInfo(
                "Wrath",
                "Unleash the wrath of Herobrine, striking all nearby enemies in a 5 block radius for &a4.5 &rtrue damage.",
                "Power",
                "Killing an enemy grants you Strength I for &a6 &rseconds.",
                "Flurry",
                "Every &a3 &rattacks will grant you Speed II for 3 seconds and Regeneration I for 5 seconds.",
                "Treasure Hunter",
                "Increases the chance to find treasure chests by &a300% &rwhen mining."
        );

        this.classInfo.addEnergyGainType("Melee", 25);
        this.classInfo.addEnergyGainType("Bow", 25);
    }

    @Override
    public void ability(Player player) {
        if (wrathList.contains(player)) return;
        World world = player.getWorld();

        boolean pass = false;

        Set<Player> cache = new HashSet<>();

        for (Player victim : Bukkit.getOnlinePlayers()) {
            if (player.getWorld() != victim.getWorld()) continue;

            Location loc = victim.getLocation();

            if (player.getLocation().distance(loc) <= 5 && player != victim && !victim.isDead() && (!plugin.getTeamsManager().isOnSameTeam(player, victim))) {
                world.strikeLightningEffect(loc);
                pass = true;

                cache.add(victim);
            }
        }

        if (pass) {
            energyManager.clear(player);
            wrathList.add(player);
            for (Player victim : cache) {
                mwhealth.trueDamage(victim, plugin.hbrTrueDamage, null);
            }

            world.playSound(player.getLocation(), Sound.ENDERMAN_DEATH, 1, (float) 0.5);
            Bukkit.getScheduler().runTaskLater(plugin, () -> wrathList.remove(player), 20);
            return;
        }

        ActionBar.send(player, "No players within " + ChatColor.RED + 5 + ChatColor.RESET + " meters!");
    }

    @Override
    public void hit(EntityDamageByEntityEvent event) {
        super.hit(event);
        if (event.isCancelled()) return;
        Player player = energyManager.validate(event);
        if (player == null) return;

        if (manager.get(player) != this) return;

        if (!increment.containsKey(player)) {
            increment.put(player, 0);
        } else {
            increment.put(player, (increment.get(player) + 1) % 3);
        }

        if (increment.get(player) == 0) {
            PotionUtils.effect(player, PotionEffectType.SPEED, 3, 1);
            PotionUtils.effect(player, PotionEffectType.REGENERATION, 5);
        }

        energyManager.add(player, 25);
    }

    @EventHandler
    public void onKill(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player player = victim.getKiller();

        if (player == null || victim == player) return;

        if (manager.get(player) == this) {
            PotionUtils.effect(player, PotionEffectType.INCREASE_DAMAGE, 6);
        }
    }

    @Override
    public void assign(Player player) {
        Map<Integer, ItemStack> items;

        
            Map<Enchantment, Integer> swordEnch = new HashMap<>();
            swordEnch.put(Enchantment.DURABILITY, 10);

            Map<Enchantment, Integer> armorEnch = new HashMap<>();
            armorEnch.put(Enchantment.PROTECTION_ENVIRONMENTAL, 2);
            armorEnch.put(Enchantment.DURABILITY, 10);
            armorEnch.put(Enchantment.WATER_WORKER, 1);

            ItemStack sword = MWItem.createSword(this, Material.DIAMOND_SWORD, swordEnch,player);
            ItemStack tool = MWItem.createTool(this, Material.DIAMOND_PICKAXE);
            ItemStack helmet = MWItem.createArmor(this, Material.IRON_HELMET, armorEnch);

            List<ItemStack> potions = MWPotions.createBasic(this, 2, 7, 2);

            items = MWKit.generate(this, sword, null, tool, null, null, potions, helmet, null, null, null, null);
        

        MWKit.assignItems(player, items);
        wrathList.remove(player);
    }

    @Override
    public String getActionBar(Player player) {
        String wrath = this.getColor() + "Wrath " + (energyManager.get(player) != 100 ? ChatColor.RED + "✖" : ChatColor.GREEN + "✔") + ChatColor.RESET;
        String flurry = this.getColor() + "Flurry " + ((!increment.containsKey(player) || increment.get(player) == 0) ? ChatColor.GREEN + "✔" : (ChatColor.RED + String.valueOf(increment.get(player)))) + ChatColor.RESET;
        return wrath + "      " + flurry;
    }
}
