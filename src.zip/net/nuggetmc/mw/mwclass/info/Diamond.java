package net.nuggetmc.mw.mwclass.info;

public enum Diamond {
    HELMET,
    CHESTPLATE,
    LEGGINGS,
    BOOTS,
    SWORD
}
