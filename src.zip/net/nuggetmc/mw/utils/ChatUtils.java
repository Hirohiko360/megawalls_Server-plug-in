package net.nuggetmc.mw.utils;

import net.md_5.bungee.api.ChatColor;

public class ChatUtils {
    public static final String LINE = ChatColor.GRAY + "------------------------------------------------";
    public static final String BULLET = "▪";
    public static final String BULLET_FORMATTED = ChatColor.GRAY + " ▪ ";
}
